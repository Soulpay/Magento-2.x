<?php

namespace Magento\Soulpay\Model\Adminhtml\Source;

use Magento\Payment\Model\Source\Cctype as PaymentCctype;

class Cctype extends PaymentCctype
{
    public function getAllowedTypes()
    {
        return [
            'VI',
            'MC',
            'AE',
            'JCB',
            'DN'
        ];
    }
}
