<?php

namespace Magento\Soulpay\Model\Adminhtml\Source;

class Installments implements \Magento\Framework\Option\ArrayInterface
{

    public function toOptionArray()
{
    $arr = $this->toArray();
    $ret = [];
    foreach ($arr as $key) {
        $ret[] = [
            'value' => $key,
            'label' => $key
        ];
    }
    return $ret;
}

    public function toArray()
    {
        return [1,2,3,4,5,6,7,8,9,10,11,12];
    }
}
