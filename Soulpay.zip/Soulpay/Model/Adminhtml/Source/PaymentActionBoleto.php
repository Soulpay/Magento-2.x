<?php

namespace Magento\Soulpay\Model\Adminhtml\Source;

use Magento\Payment\Model\Method\AbstractMethod;

class PaymentActionBoleto implements \Magento\Framework\Option\ArrayInterface
{
    public function toOptionArray()
    {
        return [
            [
                'value' => AbstractMethod::ACTION_AUTHORIZE,
                'label' => __('Authorize')
            ]
        ];
    }
}
