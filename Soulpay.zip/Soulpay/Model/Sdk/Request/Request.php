<?php

namespace Magento\Soulpay\Model\Sdk\Request;

abstract class Request
{
    protected $url;

    public function __construct($url, $isProduction)
    {
        if ($isProduction) {
            $this->url = "https://mercury.viainvestgrupo.com.br/api/v1/";
        } else {
            $this->url = "https://dev-api.portalsoulpay.com.br/api/v1/";
        }
        $this->url = $this->url . $url;
    }
}
