<?php

namespace Magento\Soulpay\Model\Sdk\Transaction;

class RecurringCancel
{
    private $orderId;

    /**
     * Get the value of orderId
     */
    public function getOrderId()
    {
        return $this->orderId;
    }

    /**
     * Set the value of orderId
     *
     * @return  self
     */
    public function setOrderId($orderId)
    {
        $this->orderId = $orderId;

        return $this;
    }
}
