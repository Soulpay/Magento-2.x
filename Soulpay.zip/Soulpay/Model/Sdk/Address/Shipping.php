<?php

namespace Magento\Soulpay\Model\Sdk\Address;

require_once 'Address.php';

class Shipping extends Address
{}
