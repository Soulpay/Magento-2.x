<?php

namespace Magento\Soulpay\Model\Sdk\Address;

require_once 'Address.php';

class Billing extends Address
{}

?>
