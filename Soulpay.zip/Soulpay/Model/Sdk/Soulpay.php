<?php

namespace Magento\Soulpay\Model\Sdk;

use Magento\Soulpay\Model\Sdk\Address\Billing;
use Magento\Soulpay\Model\Sdk\Auth\Login;
use Magento\Soulpay\Model\Sdk\Auth\Token;
use Magento\Soulpay\Model\Sdk\Customer\Customer;
use Magento\Soulpay\Model\Sdk\Request\CreditCardRequest;
use Magento\Soulpay\Model\Sdk\Request\LoginRequest;
use Magento\Soulpay\Model\Sdk\Request\TokenRequest;
use Magento\Soulpay\Model\Sdk\Transaction\CreditCard;
use Magento\Soulpay\Model\Sdk\Transaction\CreditCardTransaction;
use Magento\Soulpay\Model\Sdk\Transaction\CreditInstallment;
use Magento\Soulpay\Model\Sdk\Transaction\Payment;
use Magento\Soulpay\Model\Sdk\Transaction\BankSlip;
use Magento\Soulpay\Model\Sdk\Transaction\BankSlipTransaction;
use Magento\Soulpay\Model\Sdk\Request\BankSlipRequest;

class Soulpay
{

    private $token;
    private $email;
    private $password;
    private $environment;

    public function __construct($email, $password, $environment)
    {
        $this->email = $email;
        $this->password = $password;
        $this->environment = boolval($environment);
    }

    public function getToken()
    {
        try {
            $login = new Login();
            $login->setEmail($this->email);
            $login->setPassword($this->password);

            $loginRequest = new LoginRequest($this->environment);

            $response = $loginRequest->send(json_encode($login));

            $response['response'] = json_decode($response['response'], true);

            $this->token = (object)[
                'type' => $response['response']['type'],
                'token' => $response['response']['token'],
                'refreshToken' => $response['response']['refreshToken'],
                'creatDate' => new \DateTime('+ 15 minutes')
            ];

            $now = new \DateTime();
            if ($this->token->creatDate->getTimestamp() <  $now->getTimestamp()) {

                $refresh = new Token();
                $refresh->setRefreshToken($this->token->refreshToken);

                $refreshRequest = new TokenRequest($this->token->token, $this->environment);
                $response = $refreshRequest->send(json_encode($refresh));

                $response['response'] = json_decode($response['response'], true);

                $this->token = (object)[
                    'type' => $response['response']['type'],
                    'token' => $response['response']['token'],
                    'refreshToken' => $response['response']['refreshToken'],
                    'creatDate' => new \DateTime('+ 15 minutes')
                ];

            }

            return $this->token;
        } catch(\Exception $e) {
            throw new \Magento\Framework\Exception\LocalizedException(__($e->getMessage()));
        }
    }

    public function customer($order, $data)
    {
        $customer = new Customer();

        $address = $order->getBillingAddress();

        $customer->setId($address->getEmail());
        $customer->setName($address->getFirstname()." ".$address->getLastname());
        $customer->setEmail($address->getEmail());

        if(isset($data['cc_document'])) {
            $customer->setTaxId($data['cc_document']);
        } else {
            if(isset($data['bsDocument'])) {
                $customer->setTaxId($data['bsDocument']);
            } else {
                $customer->setTaxId('76949652070');
                //cpf gerado na net, era pra da panico aqui
            }
        }

        $customer->setDob('1997-10-03');
        $customer->setPhone1($address->getTelephone());
        $customer->setPhone2($address->getTelephone());

        return $customer;
    }

    public function billing($order)
    {
        $billing = new Billing();

        $address = $order->getBillingAddress();

        $billing->setName($address->getFirstname()." ".$address->getLastname());
        $billing->setAddress($address->getStreetLine1());
        $billing->setAddress2($address->getStreetLine2());
        $billing->setDistrict($address->getStreetLine1());//bairro
        $billing->setCity($address->getCity());
        $billing->setState($address->getRegionCode());
        $billing->setPostalCode($address->getPostcode());
        $billing->setCountry($address->getCountryId());
        $billing->setPhone($address->getTelephone());
        $billing->setEmail($address->getEmail());

        return $billing;
    }

    public function creditCard($data)
    {
        $creditCard = new CreditCard();

        $creditCard->setCardHolderName($data['cc_name'] ?? '');
        $creditCard->setNumber($data['cc_number'] ?? '');
        $creditCard->setExpDate(sprintf("%02d/%d", $data['cc_month'] ?? '', $data['cc_year'] ?? ''));
        $creditCard->setCvvNumber($data['cc_cvv'] ?? '');

        return $creditCard;
    }

    public function payCreditCard($creditCardData, $order)
    {
        $customer = $this->customer($order, $creditCardData);

        $billing = $this->billing($order);

        $creditCard = $this->creditCard($creditCardData);

        $creditInstallment = new CreditInstallment($creditCardData['cc_installment']);

        $creditInstallment->setNumberOfInstallments(1);

        $payment = new Payment();

        $payment->setChargeTotal($order->getGrandTotalAmount());
        $payment->setCurrencyCode('BRL');
        $payment->setCreditInstallment($creditInstallment);

        $creditCardTransaction = new CreditCardTransaction();

        $creditCardTransaction->setReferenceNum($order->getOrderIncrementId());
        $creditCardTransaction->setCustomer($customer);
        $creditCardTransaction->setBilling($billing);
        $creditCardTransaction->setCreditCard($creditCard);
        $creditCardTransaction->setPayment($payment);

        // Passar o token JWT aqui.
        $request = new CreditCardRequest($this->getToken()->token, $this->environment);

        try {
            $payment = json_decode($request->send(json_encode($creditCardTransaction)));

            $payment->response = json_decode($payment->response, true);
        } catch(\Exception $e) {
            $msg = $e->getMessage();
            throw new \Magento\Framework\Exception\LocalizedException(__("Nao Gerou Token {$msg} "));
        }

        $payment->response['installments'] = $creditCardData['cc_installment'];

        return $payment;
    }

    public function generateBankSlip($bankSlipData, $order)
    {
        $customer = $this->customer($order, $bankSlipData);

        $billing = $this->billing($order);

        $bankSlip = new BankSlip();
        $bankSlip->setExpirationDate($bankSlipData['expDate']);
        $bankSlip->setInstructions($bankSlipData['instructions']);

        $payment = new Payment();

        $payment->setChargeTotal($order->getGrandTotalAmount());
        $payment->setCurrencyCode('BRL');

        $bankSlipTransaction = new BankSlipTransaction();
        $bankSlipTransaction->setReferenceNum($order->getOrderIncrementId());
        $bankSlipTransaction->setCustomer($customer);
        $bankSlipTransaction->setBilling($billing);
        $bankSlipTransaction->setBankSlip($bankSlip);
        $bankSlipTransaction->setPayment($payment);

        //Passar o token JWT aqui.
        $request = new BankSlipRequest($this->getToken()->token, $this->environment);

        try {
            $payment = json_decode($request->send(json_encode($bankSlipTransaction)));
            $payment->response = json_decode($payment->response, true);
        } catch(\Exception $e) {
            $msg = $e->getMessage();
            throw new \Magento\Framework\Exception\LocalizedException(__("Nao Gerou Token {$msg} "));
        }

        return $payment;
    }

    public function getBankSlip($id) {
        try {
            $request = new BankSlipRequest($this->getToken()->token, $this->environment);
            $response = $request->get($id);
            $response["response"] = json_decode($response["response"], true);
        } catch(\Exception $e) {
            $msg = $e->getMessage();
            throw new \Magento\Framework\Exception\LocalizedException(__("Erro nao esperado {$msg} "));
        }

        return $response;
    }

    public function getCreditCard($id) {
        try {
            $request = new CreditCardRequest($this->getToken()->token, $this->environment);
            $response = $request->get($id);
            $response["response"] = json_decode($response["response"], true);
        } catch(\Exception $e) {
            $msg = $e->getMessage();
            throw new \Magento\Framework\Exception\LocalizedException(__("Erro nao esperado {$msg} "));
        }

        return $response;
    }

}
