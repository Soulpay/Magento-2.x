<?php

namespace Magento\Soulpay\Model\Sdk\Auth;

require_once 'TokenRefresh.php';

class RefreshToken extends TokenRefresh
{

}
