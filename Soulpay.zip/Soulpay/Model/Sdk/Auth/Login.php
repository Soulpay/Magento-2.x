<?php

namespace Magento\Soulpay\Model\Sdk\Auth;

class Login implements \JsonSerializable
{
    private $email;
    private $password;
    private $hash;
    private $userUID;

    public function jsonSerialize()
    {
        $vars = array_filter(
            get_object_vars($this),
            function ($item) {
                // Keep only not-NULL values
                return !is_null($item);
            }
        );

        return $vars;
    }

    /**
     * Get the value of email
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set the value of email
     *
     * @return  self
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get the value of password
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * Set the value of password
     *
     * @return  self
     */
    public function setPassword($password)
    {
        $this->password = $password;

        return $this;
    }

    /**
     * Get the value of hash
     */
    public function getHash()
    {
        return $this->hash;
    }

    /**
     * Set the value of hash
     *
     * @return  self
     */
    public function setHash($hash)
    {
        $this->hash = $hash;

        return $this;
    }

    /**
     * Get the value of hash
     */
    public function getUserUID()
    {
        return $this->userUID;
    }

    /**
     * Set the value of userUID
     *
     * @return  self
     */
    public function setUserUID($userUID)
    {
        $this->userUID = $userUID;

        return $this;
    }
}
