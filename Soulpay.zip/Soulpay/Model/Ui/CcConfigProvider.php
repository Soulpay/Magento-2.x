<?php

namespace Magento\Soulpay\Model\Ui;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Framework\View\Asset\Source;
use Magento\Soulpay\Model\Adminhtml\Source\Cctype;

final class CcConfigProvider implements ConfigProviderInterface
{
    const CODE = 'soulpay_cc';
    protected $_code = self::CODE;

    private $icons = [];
    private  $avaliableCcTypes = [];

    public function __construct(
        \Magento\Payment\Model\CcConfig $ccConfig,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        Source $assetSource,
        Cctype $customTypes
        ) {
        $this->ccConfig = $ccConfig;
        $this->scopeConfig = $scopeConfig;
        $this->assetSource = $assetSource;
        $this->customTypes = $customTypes;
    }

    public function getConfig()
    {
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $installmentValue = $this->scopeConfig->getValue('payment/soulpay_cc/intallment_value', $storeScope);
        $installmentMax = $this->scopeConfig->getValue('payment/soulpay_cc/intallment_max', $storeScope);

        foreach ($this->customTypes->getAllowedTypes() as $item) {
            $this->avaliableCcTypes[$item] = $this->ccConfig->getCcAvailableTypes()[$item];
        }

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $cart = $objectManager->get('\Magento\Checkout\Model\Cart');

        $grandTotal = $cart->getQuote()->getGrandTotal();

        return [
            'payment' => [
                self::CODE => [
                    'availableTypes' => $this->avaliableCcTypes,
                    'months' => $this->ccConfig->getCcMonths(),
                    'years' => $this->ccConfig->getCcYears(),
                    'installmentValue' => $installmentValue,
                    'installmentMax' => $installmentMax,
                    'icons' => $this->getIcons(),
                    'cartTotal' => $grandTotal
                ]
            ]
        ];
    }

    public function getIcons()
    {
        if (!empty($this->icons)) {
            return $this->icons;
        }

        $types = $this->avaliableCcTypes;
        foreach (array_keys($types) as $code) {
            if (!array_key_exists($code, $this->icons)) {
                $asset = $this->ccConfig->createAsset('Magento_Payment::images/cc/' . strtolower($code) . '.png');
                $placeholder = $this->assetSource->findSource($asset);
                if ($placeholder) {
                    list($width, $height) = getimagesize($asset->getSourceFile());
                    $this->icons[$code] = [
                        'url' => $asset->getUrl(),
                        'width' => $width,
                        'height' => $height
                    ];
                }
            }
        }

        return $this->icons;
    }
}
