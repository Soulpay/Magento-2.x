<?php

namespace Magento\Soulpay\Model\Ui;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Framework\View\Asset\Source;

final class BoletoConfigProvider implements ConfigProviderInterface
{
    const CODE = 'soulpay_boleto';
    protected $_code = self::CODE;

    public function __construct(
        \Magento\Payment\Model\CcConfig $ccConfig,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        Source $assetSource
        ) {
        $this->scopeConfig = $scopeConfig;
        $this->assetSource = $assetSource;
    }

    public function getConfig()
    {
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $title = $this->scopeConfig->getValue('payment/soulpay_boleto/title', $storeScope);

        $expdays = $this->scopeConfig->getValue('payment/soulpay_boleto/exp_days', $storeScope);
        $instructions =$this->scopeConfig->getValue('payment/soulpay_boleto/instructions', $storeScope);

        return [
            'payment' => [
                self::CODE => [
                    'title' => $title,
                    'exp_days' => $expdays,
                    'instructions' => $instructions
                ]
            ]
        ];
    }
}
