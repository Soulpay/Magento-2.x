<?php

namespace Magento\Soulpay\Cron;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Soulpay\Model\Sdk\Soulpay;
use DateTime;

class SoulpayCron
{
    protected $_logger;
    protected $_scopeConfig;
    private $boletoSoulpay;
    private $ccSoulpay;

    public function __construct(
            \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory,
            \Psr\Log\LoggerInterface $logger,
            ScopeConfigInterface $scopeConfig,
            \Magento\Sales\Model\Service\InvoiceService $invoiceService
         )
    {
        $this->objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $this->_logger = $logger;
        $this->_scopeConfig = $scopeConfig;
        $this->_orderCollectionFactory =$orderCollectionFactory;
        $this->_invoiceService = $invoiceService;
    }

    public function getOrderCollectionByProcessing()
    {
        $collection = $this->_orderCollectionFactory->create()
          ->addFieldToSelect('*')
          ->addFieldToFilter('status',
                 ['in' => ['processing']]
             )
          ->setOrder(
                 'created_at',
                 'asc'
             );

      return $collection;
    }

    public function getOrderCollectionByReview()
    {
        $collection = $this->_orderCollectionFactory->create()
           ->addFieldToSelect('*')
           ->addFieldToFilter('status',
                  ['in' => ['payment_review']]
              )
           ->setOrder(
                  'created_at',
                  'asc'
              );

        return $collection;
    }


    public function initBoleto()
    {
        $email = $this->_scopeConfig->getValue('payment/soulpay_boleto/email', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $pass = $this->_scopeConfig->getValue('payment/soulpay_boleto/password', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $env = $this->_scopeConfig->getValue('payment/soulpay_boleto/environment', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $this->boletoSoulpay = new Soulpay($email, $pass, $env);
    }

    public function initCc()
    {
        $email = $this->_scopeConfig->getValue('payment/soulpay_cc/email', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $pass = $this->_scopeConfig->getValue('payment/soulpay_cc/password', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $env = $this->_scopeConfig->getValue('payment/soulpay_cc/environment', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $this->ccSoulpay = new Soulpay($email, $pass, $env);
    }

    public function executeBoleto()
    {
        $this->initBoleto();

        $collection = $this->getOrderCollectionByProcessing();
        //loopando as orders
        foreach($collection as $order) {

            echo '* ' . $order->getState() . ' * processing orderId: ' . $order->getData('entity_id') . PHP_EOL;

            $transactionsInAuth = $this->objectManager->create('\Magento\Sales\Api\Data\TransactionSearchResultInterfaceFactory')
                    ->create()->addOrderIdFilter($order->getData('entity_id'))
                    ->addAttributeToFilter('txn_type', array('eq' => 'authorization'));

            //loopando as txn da order
            foreach ($transactionsInAuth as $transaction) {
                $info = $transaction->getAdditionalInformation('soulpay_payment');

                if($info) {
                    $info = $info[0];
                    if($info['orderType'] == 'BANKSLIP') {
                        echo ' -- processing Boleto id: ' . $info["orderId"] . PHP_EOL;
                        $expDate = DateTime::createFromFormat('Y-m-d', $info['bankSlipExpDate']);
                        $now = new DateTime();
                        $diferenca = $now->diff($expDate);

                        //boleto vencido/expirado
                        if(intval($diferenca->format('%r%a')) < -2) {
                            $this->voidTxn($transaction, "Boleto Vencido");
                            $this->txnRepository->save($transaction);
                                continue;
                        }

                        try{
                            //dados do boleto do provedor de pagamento
                            $trans = $this->boletoSoulpay->getBankSlip($info["orderId"]);
                        } catch(\Exception $e) {
                            continue;
                        }

                        //boleto expirado
                        if($trans["response"]["isRevoked"] == 1) {
                            $this->voidTxn($transaction, "Boleto Expirado");
                            $this->txnRepository->save($transaction);
                            continue;
                        }

                        //boleto pago
                        if($trans["response"]["paid"] == 1) {
                            $transaction->setAdditionalInformation('soulpay_response', $trans['response']);
                            $this->captureTxn($transaction, "Boleto Pago");
                            $this->txnRepository->save($transaction);
                            $invoice = $this->_invoiceService->prepareInvoice($order);
                            $invoice->setTransactionId($transaction->getTxnId());
                            $invoice->setRequestedCaptureCase(\Magento\Sales\Model\Order\Invoice::STATE_PAID);
                            $invoice->pay();
                            $invoice->register();
                            $invoice->save();
                        }
                    }
                }
            }

            $transactionsAll = $this->objectManager->create('\Magento\Sales\Api\Data\TransactionSearchResultInterfaceFactory')
                ->create()->addOrderIdFilter($order->getData('entity_id'));

            $update_status = $order::STATE_COMPLETE;

            //verificando todas as txn pra saber se 'cancela', 'completa' ou mantem 'processando'
            foreach ($transactionsAll as $txn) {
                if(strcmp($txn->getTxnType(), $txn::TYPE_VOID) == 0) {
                    $update_status = $order::STATE_CANCELED;
                    break;
                }
                if(strcmp($txn->getTxnType(), $txn::TYPE_AUTH) == 0) {
                    $update_status = $order::STATE_PROCESSING;
                    break;
                }
            }

            if(strcmp($order->getState(), $update_status) != 0) {
                $order->setState($update_status, true);
                $order->setStatus($update_status);
                $order->addStatusToHistory($order->getStatus(), 'Order status');
                $this->orderResourceModel->save($order);
            }
        }

    }

    public function executeCc()
    {
        $this->initCc();

        $collection = $this->getOrderCollectionByReview();

        //loopando as orders
        foreach($collection as $order) {

            echo '* ' . $order->getState() . ' * processing orderId: ' . $order->getData('entity_id') . PHP_EOL;

            $transactionsInAuth = $this->objectManager->create('\Magento\Sales\Api\Data\TransactionSearchResultInterfaceFactory')
                    ->create()->addOrderIdFilter($order->getData('entity_id'))
                    ->addAttributeToFilter('txn_type', array('eq' => 'capture'));

            $update_status = $order::STATE_PAYMENT_REVIEW ;

            //loopando as txn da order
            foreach ($transactionsInAuth as $transaction) {

                if(strcmp($update_status, $order::STATE_PAYMENT_REVIEW ) != 0) {
                    break;
                }

                $info = $transaction->getAdditionalInformation('soulpay_payment');

                if($info) {
                    $info = $info[0];

                    if($info['orderType'] == 'CREDIT CARD SALE') {
                        echo ' -- processing Cc id: ' . $info["orderId"] . PHP_EOL;

                        try{
                            $trans = $this->ccSoulpay->getCreditCard($info["orderId"]);
                        } catch(\Exception $e) {
                            continue;
                        }

                        $selectInvoice = null;

                        foreach ($order->getInvoiceCollection() as $invoice) {
                            if ($invoice->getTransactionId() == $transaction->getTxnId()) {
                                $invoice->load($invoice->getId());

                                $selectInvoice = $invoice;
                            }
                        }

                        switch (intval($trans['response']['status'])) {
                            case 1: //APROVED
                                $transaction->setAdditionalInformation('soulpay_response', $trans['response']);
                                $this->captureTxn($transaction, "Cc Pago");
                                $transaction->setIsTransactionPending(false);
                                $selectInvoice->pay();
                                $this->txnRepository->save($transaction);
                                $selectInvoice->save();
                                $update_status = $order::STATE_COMPLETE;
                                break;
                            case 2: //DANIED
                            case 7: //CAPTURE FAIL
                            case 8: //RECURRENCE FAIL
                                $this->voidTxn($transaction, "Pagamento Recusado");
                                $transaction->setIsTransactionPending(false);
                                $selectInvoice->void();
                                $this->txnRepository->save($transaction);
                                $selectInvoice->save();
                                $update_status = $order::STATE_CANCELED;
                                break;
                            case 3: //ANALYSIS
                            case 4: //NOT REPORTED
                            case 5: //PROCESSING
                            case 6: //IN TROUBLESHOOTING
                            case 9: //CREATED
                                break;
                        }
                    }
                }
            }

            if(strcmp($order->getState(), $update_status) != 0) {
                $order->setState($update_status, true);
                $order->setStatus($update_status);
                $order->addStatusToHistory($order->getStatus(), 'Order status');
                $this->orderResourceModel->save($order);
            }
        }

    }

	public function execute()
	{
        echo 'Started Soulpay Job' . PHP_EOL;
        $this->orderResourceModel = $this->objectManager->create('\Magento\Sales\Model\ResourceModel\Order');
        $this->txnRepository = $this->objectManager->create('\Magento\Sales\Model\Order\Payment\Transaction\Repository');

        $this->executeBoleto();
        $this->executeCc();

        echo 'Stoped Soulpay Job' . PHP_EOL;

		return $this;
	}

    public function voidTxn($txn, $status) {
        echo ' -- voidTxn - ' . $status . PHP_EOL;
        $txn->setIsClosed(1);
        $txn->setTxnType($txn::TYPE_VOID);
        $txn->setAdditionalInformation("txn_status", $status);
    }

    public function captureTxn($txn, $status) {
        echo ' -- captureTxn' . PHP_EOL;
        $txn->setIsClosed(1);
        $txn->setTxnType($txn::TYPE_CAPTURE);
        $txn->setAdditionalInformation("txn_status", $status);
    }

}
