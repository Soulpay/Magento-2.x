<?php

namespace Magento\Soulpay\Block;

class Thankyou extends \Magento\Sales\Block\Order\Totals
{
    protected $checkoutSession;
    protected $customerSession;
    protected $_orderFactory;
    protected Magento\Sales\Model\Order\Payment\Transaction $_transaction;

    public function __construct(
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\Registry $registry,
        array $data = []
    ) {
        parent::__construct($context, $registry, $data);
        $this->checkoutSession = $checkoutSession;
        $this->customerSession = $customerSession;
        $this->_orderFactory = $orderFactory;
    }

    public function getOrder()
    {
        return $this->_order = $this->_orderFactory->create()->loadByIncrementId($this->checkoutSession->getLastRealOrderId());
    }

    public function getCustomerId()
    {
        return $this->customerSession->getCustomer()->getId();
    }

    public function getSoulpayPaymentData()
    {
        $order = $this->_orderFactory->create()->loadByIncrementId($this->checkoutSession->getLastRealOrderId());
        $soulpay_payment = $order->getPayment()->getAdditionalInformation()["soulpay_payment"][0];
        return $soulpay_payment;
    }
}
