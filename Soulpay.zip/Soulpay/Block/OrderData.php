<?php 

namespace Magento\Soulpay\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Framework\View\Page\Config;
use Magento\Framework\Registry;

class OrderData extends Template
{
    protected $coreRegistry = null;

    public function __construct(
        Context $context,
        Registry $registry,
        Config $pageConfig,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->pageConfig = $pageConfig;
        $this->coreRegistry = $registry;
    }

    public function getPageConfig()
    {
        return $this->pageConfig;
    }

    public function getOrder()
    {
        return $this->coreRegistry->registry('current_order');
    }

    public function getSoulpayPaymentData()
    {
        $order = $this->getOrder();
        $soulpay_payment = $order->getPayment()->getAdditionalInformation()["soulpay_payment"][0];
        return $soulpay_payment;
    }
}
?>
