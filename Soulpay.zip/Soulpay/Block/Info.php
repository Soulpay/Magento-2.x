<?php

namespace Magento\Soulpay\Block;

use Magento\Framework\Phrase;
use Magento\Payment\Block\ConfigurableInfo;

class Info extends ConfigurableInfo
{
    protected function getLabel($field)
    {
        return __($field);
    }

    protected function getValueView($field, $value)
    {
        switch ($field) {
            case '':
                return implode('; ', $value);
        }
        return parent::getValueView($field, $value);
    }
}
