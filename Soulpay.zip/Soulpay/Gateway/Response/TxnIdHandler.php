<?php

namespace Magento\Soulpay\Gateway\Response;

use Magento\Payment\Gateway\Data\PaymentDataObjectInterface;
use Magento\Payment\Gateway\Response\HandlerInterface;

class TxnIdHandler implements HandlerInterface
{
    public function handle(array $handlingSubject, array $response)
    {
        if (!isset($handlingSubject['payment'])
            || !$handlingSubject['payment'] instanceof PaymentDataObjectInterface
        ) {
            throw new \InvalidArgumentException('Payment data object should be provided');
        }

        /** @var PaymentDataObjectInterface $paymentDO */
        $paymentDO = $handlingSubject['payment'];

        $order = $paymentDO->getOrder();

        $payment = $paymentDO->getPayment();

        /** @var $payment \Magento\Sales\Model\Order\Payment */
        $payment->setTransactionId($response['RESULT_SOULPAY']->response['orderId'] ?? $order->getOrderIncrementId());

        $payment->setCcTransId($response['RESULT_SOULPAY']->response['orderId'] ?? null);

        $payment->setTransactionAdditionalInfo("soulpay_payment", (array)[$response['RESULT_SOULPAY']->response ?? null]);

        //entao to jogando no AdditionalInformation </diego>
        $payment->setAdditionalInformation("soulpay_payment", (array)[$response['RESULT_SOULPAY']->response ?? null]);

        if(($response['RESULT_SOULPAY']->response['apiResponse'] ?? '') == 'REVIEWING') {
            $payment->setIsTransactionPending(true);
        }

        $payment->setIsTransactionClosed(false);
    }
}
