<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Soulpay\Gateway\Request;

use Magento\Payment\Gateway\ConfigInterface;
use Magento\Payment\Gateway\Data\PaymentDataObjectInterface;
use Magento\Payment\Gateway\Request\BuilderInterface;

class AuthorizationRequest implements BuilderInterface
{
    private $config;

    public function __construct(
        ConfigInterface $config
    ) {
        $this->config = $config;
    }

    public function build(array $buildSubject)
    {
        if (!isset($buildSubject['payment'])
            || !$buildSubject['payment'] instanceof PaymentDataObjectInterface
        ) {
            throw new \InvalidArgumentException('Payment data object should be provided');
        }

        /** @var PaymentDataObjectInterface $payment */
        $payment = $buildSubject['payment'];
        $order = $payment->getOrder();
        $data = $payment->getPayment();

        return [
            'TXN_TYPE' => 'A',
            'ORDER' => $order,
            "PAY_DATA" => $data->getAdditionalInformation('additional_data'),
            'PSP_EMAIL' => $this->config->getValue(
                'email',
                $order->getStoreId()
            ),
            'PSP_PASSWORD' => $this->config->getValue(
                'password',
                $order->getStoreId()
            ),
            'PSP_ENVIRONMENT' => $this->config->getValue(
                'environment',
                $order->getStoreId()
            )
        ];
    }
}
