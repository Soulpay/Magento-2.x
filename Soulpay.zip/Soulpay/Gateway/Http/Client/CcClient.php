<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Soulpay\Gateway\Http\Client;

use Magento\Payment\Gateway\Http\ClientInterface;
use Magento\Payment\Gateway\Http\TransferInterface;
use Magento\Payment\Model\Method\Logger;
use Magento\Soulpay\Model\Sdk\Soulpay;

class CcClient implements ClientInterface
{
    const SUCCESS = 1;
    const FAILURE = 0;

    private $logger;

    public function __construct(
        Logger $logger
    ) {
        $this->logger = $logger;
    }

    public function placeRequest(TransferInterface $transferObject)
    {
        $body = $transferObject->getBody();

        $soulpay = new Soulpay($body['PSP_EMAIL'], $body['PSP_PASSWORD'], $body['PSP_ENVIRONMENT']);

        $cc = $body['PAY_DATA'];
        $order = $body['ORDER'];

        $payment = $soulpay->payCreditCard($cc, $order);

        if($payment->httpCode >= 400 || $payment->response['apiResponse'] == 'DENIED' || $payment->response['apiResponse'] == 'DECLINED') {

            if($payment->httpCode >= 400 ) {
                $msg = $payment->response['errors'][0]['field'] ?? 'Falha ao Comprar';
                throw new \Magento\Framework\Exception\LocalizedException(__("Verifique os dados preenchido: {$msg}"));
            }

            throw new \Magento\Framework\Exception\LocalizedException(__("Compra recusada, entre em contato com emissor do cartão"));
       }

        return [ 'RESULT_SOULPAY' => $payment ];
    }

}
