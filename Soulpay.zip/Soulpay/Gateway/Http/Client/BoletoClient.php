<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Soulpay\Gateway\Http\Client;

use Magento\Payment\Gateway\Http\ClientInterface;
use Magento\Payment\Gateway\Http\TransferInterface;
use Magento\Payment\Model\Method\Logger;
use Magento\Soulpay\Model\Sdk\Soulpay;
use DateTime;
use DateInterval;

class BoletoClient implements ClientInterface
{
    const SUCCESS = 1;
    const FAILURE = 0;

    private $logger;

    public function __construct(
        Logger $logger
    ) {
        $this->logger = $logger;
    }

    public function placeRequest(TransferInterface $transferObject)
    {
        $body = $transferObject->getBody();

        $soulpay = new Soulpay($body['PSP_EMAIL'], $body['PSP_PASSWORD'], $body['PSP_ENVIRONMENT']);

        $bs = $body['PAY_DATA'];
        $order = $body['ORDER'];

        $expDate = new DateTime();
        $interval = new DateInterval('P1D');

        for($i = 0; $i < $bs['exp_days']; $i++) {
            do {
                $expDate->add($interval);
            } while($expDate->format('w') == 0 || $expDate->format('w') == 6 || $this->isFeriado($expDate));
            //                  Domingo = 0 ||              Sabado = 6
        }

        $bs['expDate'] = $expDate->format('Y-m-d');

        $payment = $soulpay->generateBankSlip($bs, $order);

        if($payment->httpCode >= 400 || $payment->response['apiResponse'] == 'DENIED' || $payment->response['apiResponse'] == 'DECLINED') {

            if($payment->httpCode >= 400 ) {
                $msg = $payment->response['errors'][0]['field'] ?? 'Falha ao Gerar o Boleto';
                throw new \Magento\Framework\Exception\LocalizedException(__("Verifique os dados preenchido: {$msg}"));
            }

            throw new \Magento\Framework\Exception\LocalizedException(__("Compra recusada, revise os dados preenchidos"));
        }

        return [ 'RESULT_SOULPAY' => $payment ];
    }

    //https://gist.github.com/guiliredu/fc5ae6c9f1033384169c3b8c75f4cd61
    function isFeriado(DateTime $data = null)
    {
        if(empty($data))
        {
            $data = new DateTime();
        }

        $ano = $data->format('Y');

        $pascoa = easter_date($ano); // Limite de 1970 ou após 2037 da easter_date PHP consulta http://www.php.net/manual/pt_BR/function.easter-date.php
        $dia_pascoa = date('j', $pascoa);
        $mes_pascoa = date('n', $pascoa);
        $ano_pascoa = date('Y', $pascoa);

        $feriados = array(
            // Tatas Fixas dos feriados Nacionail Basileiras
            mktime(0, 0, 0, 1, 1, $ano), // Confraternização Universal - Lei nº 662, de 06/04/49
            mktime(0, 0, 0, 4, 21, $ano), // Tiradentes - Lei nº 662, de 06/04/49
            mktime(0, 0, 0, 5, 1, $ano), // Dia do Trabalhador - Lei nº 662, de 06/04/49
            mktime(0, 0, 0, 9, 7, $ano), // Dia da Independência - Lei nº 662, de 06/04/49
            mktime(0, 0, 0, 10, 12, $ano), // N. S. Aparecida - Lei nº 6802, de 30/06/80
            mktime(0, 0, 0, 11, 2, $ano), // Todos os santos - Lei nº 662, de 06/04/49
            mktime(0, 0, 0, 11, 15, $ano), // Proclamação da republica - Lei nº 662, de 06/04/49
            mktime(0, 0, 0, 12, 25, $ano), // Natal - Lei nº 662, de 06/04/49

            // Essas Datas depem diretamente da data de Pascoa
            // mktime(0, 0, 0, $mes_pascoa, $dia_pascoa - 48, $ano_pascoa), //2ºferia Carnaval
            mktime(0, 0, 0, $mes_pascoa, $dia_pascoa - 47, $ano_pascoa), //3ºferia Carnaval
            mktime(0, 0, 0, $mes_pascoa, $dia_pascoa - 2, $ano_pascoa), //6ºfeira Santa
            mktime(0, 0, 0, $mes_pascoa, $dia_pascoa, $ano_pascoa), //Pascoa
            mktime(0, 0, 0, $mes_pascoa, $dia_pascoa + 60, $ano_pascoa), //Corpus Cirist

        );

        sort($feriados);

        $check = mktime(0, 0, 0, $data->format('m'), $data->format('d'), $ano);

        return in_array($check, $feriados);
    }

}


