<?php

namespace Magento\Soulpay\Gateway\Validator;

use Magento\Payment\Gateway\Validator\AbstractValidator;
class ResponseCodeValidator extends AbstractValidator
{
    const RESULT_CODE = 'RESULT_CODE';


    public function validate(array $validationSubject)
    {
        if (!isset($validationSubject['response']) || !is_array($validationSubject['response'])) {
            throw new \InvalidArgumentException('Response does not exist');
        }

        $validationSubject['response'];

        return $this->createResult(
            true,
            []
        );

    }
}
