define([
    'underscore',
    'Magento_Checkout/js/view/payment/default',
    'jquery',
    ], function (_, Component, $) {
        'use strict';
        return Component.extend({
            defaults: {
                template: 'Magento_Soulpay/payment/formBoleto',
                bsDocument: '',
                bsName: '',
                exp_days: '',
                instructions: ''
            },
            initObservable: function () {
                this._super()
                    .observe([
                        'bsDocument',
                        'bsName',
                        'exp_days',
                        'instructions'
                    ]);
                return this;
            },
            getData: function() {
                return {
                    'method': this.item.method,
                    'additional_data': {
                        'bsDocument': this.bsDocument(),
                        'bsName': this.bsName(),
                        'exp_days': this.getExpDays(),
                        'instructions': this.getInstructions()
                    }
                };
            },
            initialize: function() {
                var self = this;
                this._super();
            },
            getCode: function() {
                return 'soulpay_boleto';
            },
            isActive: function() {
                return true;
            },
            validate: function() {
                var $form = $('#' + this.getCode() + '-form');
                return $form.validation() && $form.validation('isValid');
            },
            getExpDays: function() {
                return window.checkoutConfig.payment.soulpay_boleto.exp_days;
            },
            getInstructions: function() {
                return window.checkoutConfig.payment.soulpay_boleto.instructions;
            }
        });
    }
);
