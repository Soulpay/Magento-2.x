define([
    'jquery',
    'jquery/ui',
    'jquery/validate',
    'mage/translate'
    ], function($){
        'use strict';
        return function() {
            $.validator.addMethod(
                "documentvalidationrule",
                function(value, element) {

                    const cpfInvalidos = [
                        '00000000000',
                        '11111111111',
                        '22222222222',
                        '33333333333',
                        '44444444444',
                        '55555555555',
                        '66666666666',
                        '88888888888',
                        '99999999999',
                    ];

                    const cnpjInvalidos =[
                        '00000000000000',
                        '11111111111111',
                        '22222222222222',
                        '33333333333333',
                        '44444444444444',
                        '55555555555555',
                        '66666666666666',
                        '88888888888888',
                        '99999999999999',
                    ];

                    if (value && value === '') {
                        return false;
                    }

                    value = value.replace(/\D/g,'');

                    if (value.length == 11) {
                        if (cpfInvalidos.includes(value)) {
                            return false;
                        } else {
                            for (let t = 9; t < 11; t++) {
                                let d = 0,  c = 0;
                                for (; c < t; c++) {
                                    d += value[c] * ((t + 1) - c);
                                }
                                d = ((10 * d) % 11) % 10;
                                if (value[c] != d) {
                                    return false;
                                }
                            }
                        }
                        return true;
                    } else if (value.length == 14) {
                        if (cnpjInvalidos.includes(value)) {
                            return false;
                        } else {
                            for (let t = 12; t < 14; t++) {
                                let d,  m , i;
                                for (d = 0, m = (t - 7), i = 0; i < t; i++) {
                                    d += value[i] * m;
                                    m = (m == 2 ? 9 : --m);
                                }
                                d = ((10 * d) % 11) % 10;
                                if (value[i] != d) {
                                    return false;
                                }
                            }
                        }
                        return true;
                    } else {
                        return false;
                    }

                },
                $.mage.__("CPF/CNPJ Incorreto")
            );
    }
});
