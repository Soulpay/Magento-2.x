
var config = {
    config: {
        mixins: {
            'mage/validation': {
                'Magento_Soulpay/js/validator/documentValidationRule': true
            }
        }
    }
 };
